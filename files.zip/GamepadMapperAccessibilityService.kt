// ═══════════════════════════════════════════════════════════════
// FILE: service/GamepadMapperAccessibilityService.kt
// PURPOSE: The CORE touch injection engine.
//
//   Uses AccessibilityService.dispatchGesture() (API 24+) to fire
//   real multi-touch events anywhere on screen WITHOUT root access.
//
//   Receives commands via LocalBroadcastManager from OverlayService.
//   Handles:
//     - Single tap  (digital buttons)
//     - Long press  (hold buttons)
//     - Linear swipe (D-Pad directions)
//     - Continuous circular gesture (analog stick movement)
//
// HOW TO ENABLE (user must do this manually):
//   Settings → Accessibility → Installed Services
//   → "Gamepad Mapper" → Enable
// ═══════════════════════════════════════════════════════════════
package com.gamepadmapper.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.gamepadmapper.data.ButtonMapping
import kotlin.math.cos
import kotlin.math.sin

class GamepadMapperAccessibilityService : AccessibilityService() {

    companion object {
        const val TAG = "GamepadA11y"

        // Broadcast action constants — OverlayService sends these
        const val ACTION_TAP_DOWN   = "com.gamepadmapper.TAP_DOWN"
        const val ACTION_TAP_UP     = "com.gamepadmapper.TAP_UP"
        const val ACTION_ANALOG_MOVE = "com.gamepadmapper.ANALOG_MOVE"
        const val ACTION_SWIPE      = "com.gamepadmapper.SWIPE"

        // Broadcast extras
        const val EXTRA_X           = "extra_x"
        const val EXTRA_Y           = "extra_y"
        const val EXTRA_AXIS_X      = "extra_axis_x"
        const val EXTRA_AXIS_Y      = "extra_axis_y"
        const val EXTRA_RADIUS      = "extra_radius"
        const val EXTRA_INPUT_ID    = "extra_input_id"

        // Singleton ref so OverlayService can detect if A11y is active
        @Volatile
        var instance: GamepadMapperAccessibilityService? = null
            private set

        fun isEnabled(): Boolean = instance != null
    }

    private val handler = Handler(Looper.getMainLooper())

    // Track active gestures per input to cancel on button release
    private val activeGestures = mutableMapOf<String, GestureDescription.Builder>()

    // Analog stick: track ongoing stroke path
    private val analogPaths = mutableMapOf<String, AnalogState>()

    // ═══════════════════════════════════════════════════════════
    // Lifecycle
    // ═══════════════════════════════════════════════════════════

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        registerReceivers()
        Log.d(TAG, "AccessibilityService connected — touch injection ready")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        unregisterReceivers()
        Log.d(TAG, "AccessibilityService destroyed")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // We don't need to read UI events — only inject gestures.
        // This intentionally left empty.
    }

    override fun onInterrupt() {
        Log.w(TAG, "AccessibilityService interrupted")
    }

    // ═══════════════════════════════════════════════════════════
    // Broadcast Receiver Registration
    // ═══════════════════════════════════════════════════════════

    private val touchReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                ACTION_TAP_DOWN   -> handleTapDown(intent)
                ACTION_TAP_UP     -> handleTapUp(intent)
                ACTION_ANALOG_MOVE -> handleAnalogMove(intent)
                ACTION_SWIPE      -> handleSwipe(intent)
            }
        }
    }

    private fun registerReceivers() {
        val filter = IntentFilter().apply {
            addAction(ACTION_TAP_DOWN)
            addAction(ACTION_TAP_UP)
            addAction(ACTION_ANALOG_MOVE)
            addAction(ACTION_SWIPE)
        }
        LocalBroadcastManager.getInstance(this)
            .registerReceiver(touchReceiver, filter)
    }

    private fun unregisterReceivers() {
        LocalBroadcastManager.getInstance(this)
            .unregisterReceiver(touchReceiver)
    }

    // ═══════════════════════════════════════════════════════════
    // TAP: Digital Button Press
    // ═══════════════════════════════════════════════════════════

    /**
     * Fires a touch-down event at (x, y).
     * The finger stays DOWN until handleTapUp() is called,
     * which allows proper hold/charged inputs in games.
     */
    private fun handleTapDown(intent: Intent) {
        val x = intent.getFloatExtra(EXTRA_X, 0f)
        val y = intent.getFloatExtra(EXTRA_Y, 0f)
        val inputId = intent.getStringExtra(EXTRA_INPUT_ID) ?: return

        Log.d(TAG, "TAP DOWN at ($x, $y) for $inputId")

        // Path: single stationary point = tap
        val path = Path().apply { moveTo(x, y) }

        // Duration set to 60s max — will be cancelled by TAP_UP
        // GestureDescription works in milliseconds
        val stroke = GestureDescription.StrokeDescription(
            path,
            0L,         // startTime
            60_000L,    // duration (60s — cancelled early on button release)
            true        // willContinue = true allows interruption
        )

        val gesture = GestureDescription.Builder()
            .addStroke(stroke)
            .build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                Log.d(TAG, "Tap gesture completed for $inputId")
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                Log.d(TAG, "Tap gesture cancelled for $inputId")
            }
        }, handler)
    }

    /**
     * Cancels the ongoing touch-down by dispatching a zero-duration
     * continuation stroke (finger lift).
     */
    private fun handleTapUp(intent: Intent) {
        val x = intent.getFloatExtra(EXTRA_X, 0f)
        val y = intent.getFloatExtra(EXTRA_Y, 0f)

        Log.d(TAG, "TAP UP at ($x, $y)")

        // A zero-length stroke at the same position = finger lift
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(
            path,
            0L,
            1L,     // 1ms = instant release
            false   // willContinue = false ends the gesture
        )

        dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            null,
            handler
        )
    }

    // ═══════════════════════════════════════════════════════════
    // ANALOG STICK: Continuous Swipe Translation
    // ═══════════════════════════════════════════════════════════

    /**
     * Translates an analog stick position (axisX, axisY in -1..1)
     * into a sustained circular gesture around the center point.
     *
     * If axisX/axisY are both ~0, lifts the finger (stick released).
     */
    private fun handleAnalogMove(intent: Intent) {
        val centerX = intent.getFloatExtra(EXTRA_X, 0f)
        val centerY = intent.getFloatExtra(EXTRA_Y, 0f)
        val axisX   = intent.getFloatExtra(EXTRA_AXIS_X, 0f)
        val axisY   = intent.getFloatExtra(EXTRA_AXIS_Y, 0f)
        val radius  = intent.getFloatExtra(EXTRA_RADIUS, 80f)
        val inputId = intent.getStringExtra(EXTRA_INPUT_ID) ?: return

        val magnitude = Math.sqrt((axisX * axisX + axisY * axisY).toDouble()).toFloat()

        if (magnitude < 0.05f) {
            // Stick returned to center → lift finger
            liftAnalogFinger(centerX, centerY)
            analogPaths.remove(inputId)
            return
        }

        // Map stick position to screen offset
        val targetX = centerX + (axisX * radius)
        val targetY = centerY + (axisY * radius)

        val state = analogPaths.getOrPut(inputId) {
            AnalogState(currentX = centerX, currentY = centerY)
        }

        // Smooth interpolation toward target (reduces jitter)
        val smoothX = state.currentX + (targetX - state.currentX) * 0.4f
        val smoothY = state.currentY + (targetY - state.currentY) * 0.4f

        state.currentX = smoothX
        state.currentY = smoothY

        // Build a short linear stroke from last position to new position
        val path = Path().apply {
            moveTo(state.currentX, state.currentY)
            lineTo(smoothX, smoothY)
        }

        val stroke = GestureDescription.StrokeDescription(
            path,
            0L,
            16L,    // ~1 frame at 60fps for smooth continuous motion
            true    // willContinue — keeps finger down
        )

        dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    // Stroke complete — next frame's move will chain on
                }
            },
            handler
        )
    }

    private fun liftAnalogFinger(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 1L, false)
        dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            null,
            handler
        )
    }

    // ═══════════════════════════════════════════════════════════
    // SWIPE: D-Pad Directional Input
    // ═══════════════════════════════════════════════════════════

    /**
     * Fires a directional swipe gesture.
     * Used for D-Pad inputs that need swipe (e.g. scroll, page turn).
     * For tap-based D-Pad, use handleTapDown/Up instead.
     */
    private fun handleSwipe(intent: Intent) {
        val startX  = intent.getFloatExtra(EXTRA_X, 0f)
        val startY  = intent.getFloatExtra(EXTRA_Y, 0f)
        val axisX   = intent.getFloatExtra(EXTRA_AXIS_X, 0f)
        val axisY   = intent.getFloatExtra(EXTRA_AXIS_Y, 0f)
        val radius  = intent.getFloatExtra(EXTRA_RADIUS, 120f)

        val endX = startX + axisX * radius
        val endY = startY + axisY * radius

        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }

        val stroke = GestureDescription.StrokeDescription(path, 0L, 200L, false)
        dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            null,
            handler
        )
    }

    // ═══════════════════════════════════════════════════════════
    // Data Classes
    // ═══════════════════════════════════════════════════════════

    data class AnalogState(var currentX: Float, var currentY: Float)
}
