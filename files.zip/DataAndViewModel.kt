// ═══════════════════════════════════════════════════════════════
// FILE: data/GameProfile.kt
// ═══════════════════════════════════════════════════════════════
package com.gamepadmapper.data

import com.gamepadmapper.input.GamepadInput

/**
 * A named set of button mappings for one game.
 */
data class GameProfile(
    val name: String,
    val gameName: String = "",
    val hudImagePath: String = "",        // Absolute path to saved HUD screenshot
    val mappings: List<ButtonMapping> = emptyList(),
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * One physical button → one screen coordinate.
 */
data class ButtonMapping(
    val inputId: String,                  // e.g. "BTN_A", "AXIS_LEFT"
    val displayName: String,              // e.g. "A", "Left Stick"
    val screenX: Float,                   // Absolute screen X (pixels)
    val screenY: Float,                   // Absolute screen Y (pixels)
    val isAnalog: Boolean = false,
    val analogRadius: Float = 80f         // Pixels, how far the simulated finger travels
)


// ═══════════════════════════════════════════════════════════════
// FILE: data/ProfileRepository.kt
// PURPOSE: Read/write GameProfiles as JSON files in private storage.
//          Uses Gson. Each profile = one JSON file: profiles/<name>.json
// ═══════════════════════════════════════════════════════════════
package com.gamepadmapper.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import java.io.File

class ProfileRepository(private val context: Context) {

    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()
    private val profilesDir: File get() = File(context.filesDir, "profiles").also { it.mkdirs() }

    // ── CRUD ──────────────────────────────────────────────────

    fun saveProfile(profile: GameProfile) {
        val file = File(profilesDir, "${sanitize(profile.name)}.json")
        file.writeText(gson.toJson(profile))
    }

    fun loadProfile(name: String): GameProfile? {
        val file = File(profilesDir, "${sanitize(name)}.json")
        if (!file.exists()) return null
        return runCatching { gson.fromJson(file.readText(), GameProfile::class.java) }.getOrNull()
    }

    fun deleteProfile(name: String) {
        File(profilesDir, "${sanitize(name)}.json").delete()
    }

    fun listProfiles(): List<GameProfile> {
        return profilesDir
            .listFiles { f -> f.extension == "json" }
            ?.mapNotNull { f ->
                runCatching { gson.fromJson(f.readText(), GameProfile::class.java) }.getOrNull()
            }
            ?.sortedByDescending { it.createdAt }
            ?: emptyList()
    }

    private fun sanitize(name: String): String =
        name.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
}


// ═══════════════════════════════════════════════════════════════
// FILE: viewmodel/MappingViewModel.kt
// PURPOSE: State management for MappingActivity.
//          Bridges between UI events and data layer.
// ═══════════════════════════════════════════════════════════════
package com.gamepadmapper.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.gamepadmapper.data.ButtonMapping
import com.gamepadmapper.data.GameProfile
import com.gamepadmapper.data.ProfileRepository
import com.gamepadmapper.input.GamepadInput
import com.gamepadmapper.ui.DraggableButtonView

class MappingViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ProfileRepository(application)

    // ── Observable State ──────────────────────────────────────
    private val _hudImageUri = MutableLiveData<Uri?>()
    val hudImageUri: LiveData<Uri?> = _hudImageUri

    private val _profileSaved = MutableLiveData<Boolean>()
    val profileSaved: LiveData<Boolean> = _profileSaved

    // ── In-memory position tracking ───────────────────────────
    // Maps inputId → (x, y) as the user drags buttons
    private val positionMap = mutableMapOf<String, Pair<Float, Float>>()

    private var currentProfileName: String = ""

    // ── Profile Loading ───────────────────────────────────────

    fun loadProfile(name: String) {
        currentProfileName = name
        val profile = repository.loadProfile(name) ?: return
        profile.hudImagePath.takeIf { it.isNotBlank() }?.let {
            _hudImageUri.value = Uri.parse(it)
        }
    }

    // ── Position Updates (called from DraggableButtonView.onDropped) ──

    fun updateButtonPosition(inputId: String, x: Float, y: Float) {
        positionMap[inputId] = Pair(x, y)
    }

    // ── Build Mappings from current view state ────────────────

    fun buildMappings(
        activeViews: Map<String, DraggableButtonView>
    ): List<ButtonMapping> {
        return activeViews.mapNotNull { (inputId, view) ->
            val (x, y) = positionMap[inputId] ?: Pair(view.centerX, view.centerY)
            val isAnalog = view.gamepadInput is GamepadInput.AxisLeftStick
                        || view.gamepadInput is GamepadInput.AxisRightStick
                        || view.gamepadInput is GamepadInput.AxisL2Trigger
                        || view.gamepadInput is GamepadInput.AxisR2Trigger

            ButtonMapping(
                inputId     = inputId,
                displayName = view.gamepadInput.displayName,
                screenX     = x,
                screenY     = y,
                isAnalog    = isAnalog,
                analogRadius = if (isAnalog) 100f else 0f
            )
        }
    }

    // ── Saving ────────────────────────────────────────────────

    fun saveProfile(mappings: List<ButtonMapping>) {
        val profile = GameProfile(
            name     = currentProfileName,
            mappings = mappings,
            hudImagePath = _hudImageUri.value?.toString() ?: ""
        )
        repository.saveProfile(profile)
        _profileSaved.value = true
    }

    fun saveHudImage(uri: Uri) {
        _hudImageUri.value = uri
    }

    // ── Utility ───────────────────────────────────────────────

    fun getAllProfiles(): List<GameProfile> = repository.listProfiles()
}
