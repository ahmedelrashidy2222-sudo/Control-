// ═══════════════════════════════════════════════════════════════
// FILE: ui/DraggableButtonView.kt
// PURPOSE: A self-contained View that:
//   1. Spawns at screen center with a spawn animation
//   2. Can be freely dragged by touch
//   3. Shows the button label (A, B, L1, Left Stick…)
//   4. Emits a callback when the user lifts their finger (drop)
//   5. Glows when selected, dims when locked
// ═══════════════════════════════════════════════════════════════
package com.gamepadmapper.ui

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import androidx.core.content.ContextCompat
import com.gamepadmapper.R
import com.gamepadmapper.input.GamepadInput

class DraggableButtonView(
    context: Context,
    val gamepadInput: GamepadInput,
    private val parentWidth: Int,
    private val parentHeight: Int
) : View(context) {

    // ── Geometry ─────────────────────────────────────────────
    private val buttonRadius = dpToPx(32f)  // 64dp diameter touch target
    private val strokeWidth  = dpToPx(2.5f)

    // ── Paint objects ────────────────────────────────────────
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = this@DraggableButtonView.strokeWidth
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = dpToPx(13f)
        isFakeBoldText = true
        color = Color.WHITE
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        maskFilter = BlurMaskFilter(dpToPx(16f), BlurMaskFilter.Blur.NORMAL)
    }

    // ── Colors from gamer theme ──────────────────────────────
    private val accentCyan  = Color.parseColor("#00F5FF")
    private val accentAmber = Color.parseColor("#FFB800")
    private val lockedColor = Color.parseColor("#44FFFFFF")
    private val bgColor     = Color.parseColor("#CC0D1117")  // Dark translucent

    // ── State ─────────────────────────────────────────────────
    var isLocked: Boolean = false
        set(value) { field = value; invalidate() }

    var isDragging: Boolean = false
        private set

    // Callback: (finalX: Float, finalY: Float) in PARENT coordinates
    var onDropped: ((Float, Float) -> Unit)? = null

    // Touch offset so button doesn't "jump" to finger center
    private var touchOffsetX = 0f
    private var touchOffsetY = 0f

    // Current center position in parent
    var centerX: Float = parentWidth / 2f
    var centerY: Float = parentHeight / 2f

    // ── Initialization ────────────────────────────────────────
    init {
        elevation = dpToPx(8f)
        isClickable = true
        isFocusable = true

        // Size the view: diameter + glow padding
        val size = (buttonRadius * 2 + dpToPx(20f)).toInt()
        layoutParams = android.widget.FrameLayout.LayoutParams(size, size).also {
            it.leftMargin = (centerX - size / 2).toInt()
            it.topMargin  = (centerY - size / 2).toInt()
        }

        setLayerType(LAYER_TYPE_SOFTWARE, null)  // Needed for BlurMaskFilter
        playSpawnAnimation()
    }

    // ── Drawing ───────────────────────────────────────────────
    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f

        val accentColor = if (isLocked) lockedColor else accentCyan
        val alpha = if (isLocked) 0.6f else 1.0f

        // Glow halo (software layer required)
        if (!isLocked) {
            glowPaint.color = Color.argb(80, 0, 245, 255)
            canvas.drawCircle(cx, cy, buttonRadius + dpToPx(6f), glowPaint)
        }

        // Background fill
        fillPaint.color = bgColor
        canvas.drawCircle(cx, cy, buttonRadius, fillPaint)

        // Stroke ring
        strokePaint.color = accentColor
        strokePaint.alpha = (alpha * 255).toInt()
        canvas.drawCircle(cx, cy, buttonRadius - strokeWidth / 2f, strokePaint)

        // Inner highlight arc (top-left quadrant, gives 3D feel)
        val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dpToPx(1.5f)
            color = Color.argb(60, 255, 255, 255)
        }
        canvas.drawArc(
            cx - buttonRadius + dpToPx(4f), cy - buttonRadius + dpToPx(4f),
            cx + buttonRadius - dpToPx(4f), cy + buttonRadius - dpToPx(4f),
            200f, 120f, false, highlightPaint
        )

        // Button label
        labelPaint.color = if (isLocked) Color.argb(150, 255, 255, 255) else Color.WHITE
        val label = if (gamepadInput.displayName.length > 6)
            gamepadInput.displayName.take(5) + "…"
        else
            gamepadInput.displayName

        canvas.drawText(label, cx, cy + labelPaint.textSize / 3f, labelPaint)

        // Lock icon overlay
        if (isLocked) {
            labelPaint.textSize = dpToPx(9f)
            labelPaint.color = Color.argb(180, 255, 184, 0)
            canvas.drawText("🔒", cx, cy + buttonRadius - dpToPx(6f), labelPaint)
        }
    }

    // ── Touch Handling: drag logic ────────────────────────────
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (isLocked) return false  // Locked buttons are immovable

        val parentView = parent as? android.view.ViewGroup ?: return false

        // Convert touch to parent coordinates
        val parentX = x + event.x
        val parentY = y + event.y

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                isDragging = true
                touchOffsetX = event.x - width / 2f
                touchOffsetY = event.y - height / 2f
                elevation = dpToPx(16f)   // Lift above other buttons
                animatePickUp()
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val newLeft = (parentX - touchOffsetX - width / 2f)
                    .coerceIn(0f, parentWidth - width.toFloat())
                val newTop  = (parentY - touchOffsetY - height / 2f)
                    .coerceIn(0f, parentHeight - height.toFloat())

                x = newLeft
                y = newTop
                centerX = newLeft + width / 2f
                centerY = newTop + height / 2f
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isDragging = false
                elevation = dpToPx(8f)
                animateDrop()
                onDropped?.invoke(centerX, centerY)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    // ── Animations ────────────────────────────────────────────

    private fun playSpawnAnimation() {
        scaleX = 0f; scaleY = 0f; alpha = 0f

        AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(this@DraggableButtonView, SCALE_X, 0f, 1f),
                ObjectAnimator.ofFloat(this@DraggableButtonView, SCALE_Y, 0f, 1f),
                ObjectAnimator.ofFloat(this@DraggableButtonView, ALPHA,   0f, 1f)
            )
            interpolator = OvershootInterpolator(2.5f)
            duration = 350
            start()
        }
    }

    private fun animatePickUp() {
        AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(this@DraggableButtonView, SCALE_X, 1f, 1.15f),
                ObjectAnimator.ofFloat(this@DraggableButtonView, SCALE_Y, 1f, 1.15f)
            )
            duration = 120
            start()
        }
    }

    private fun animateDrop() {
        AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(this@DraggableButtonView, SCALE_X, 1.15f, 1f),
                ObjectAnimator.ofFloat(this@DraggableButtonView, SCALE_Y, 1.15f, 1f)
            )
            interpolator = OvershootInterpolator(3f)
            duration = 200
            start()
        }
    }

    fun playLockAnimation() {
        // Pulse amber on lock
        AnimatorSet().apply {
            playSequentially(
                ObjectAnimator.ofFloat(this@DraggableButtonView, SCALE_X, 1f, 1.2f),
                ObjectAnimator.ofFloat(this@DraggableButtonView, SCALE_X, 1.2f, 0.95f),
                ObjectAnimator.ofFloat(this@DraggableButtonView, SCALE_X, 0.95f, 1f)
            )
            duration = 400
            start()
        }
        isLocked = true
    }

    // ── Utility ───────────────────────────────────────────────
    private fun dpToPx(dp: Float): Float =
        dp * context.resources.displayMetrics.density
}
