// ═══════════════════════════════════════════════════════════════
// FILE: ui/JoystickOverlayView.kt
// PURPOSE: Subclass of DraggableButtonView for analog sticks.
//          Shows a ring with an inner circle indicating direction.
//          Draggable like a button to set its screen position.
// ═══════════════════════════════════════════════════════════════
package com.gamepadmapper.ui

import android.content.Context
import android.graphics.*
import com.gamepadmapper.input.GamepadInput

class JoystickOverlayView(
    context: Context,
    gamepadInput: GamepadInput,
    parentWidth: Int,
    parentHeight: Int
) : DraggableButtonView(context, gamepadInput, parentWidth, parentHeight) {

    // Live axis values (updated during execution mode)
    var currentAxisX: Float = 0f
    var currentAxisY: Float = 0f

    private val outerRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        color = Color.parseColor("#00F5FF")
    }
    private val innerDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#FFB800")
    }
    private val radiusFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(30, 0, 245, 255)
    }

    private val outerRadius get() = width / 2f - dpToPx(6f)
    private val innerRadius get() = dpToPx(10f)
    private val maxTravel   get() = outerRadius - innerRadius

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)  // Draw base button (label, glow, ring)

        val cx = width / 2f
        val cy = height / 2f

        // Outer dashed ring = joystick boundary
        outerRingPaint.pathEffect = DashPathEffect(floatArrayOf(8f, 6f), 0f)
        canvas.drawCircle(cx, cy, outerRadius, outerRingPaint)

        // Inner fill (translucent)
        canvas.drawCircle(cx, cy, outerRadius, radiusFillPaint)

        // Inner dot = current stick position
        val dotX = cx + currentAxisX * maxTravel
        val dotY = cy + currentAxisY * maxTravel
        canvas.drawCircle(dotX, dotY, innerRadius, innerDotPaint)

        // Direction line from center to dot
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2f
            color = Color.argb(120, 255, 184, 0)
        }
        canvas.drawLine(cx, cy, dotX, dotY, linePaint)
    }

    fun updateAxis(x: Float, y: Float) {
        currentAxisX = x.coerceIn(-1f, 1f)
        currentAxisY = y.coerceIn(-1f, 1f)
        invalidate()
    }

    private fun dpToPx(dp: Float): Float =
        dp * context.resources.displayMetrics.density
}


// ═══════════════════════════════════════════════════════════════
// FILE: app/build.gradle  (Groovy DSL)
// PURPOSE: All required dependencies for the project
// ═══════════════════════════════════════════════════════════════

/*
plugins {
    id 'com.android.application'
    id 'org.jetbrains.kotlin.android'
    id 'kotlin-kapt'
}

android {
    namespace 'com.gamepadmapper'
    compileSdk 34

    defaultConfig {
        applicationId "com.gamepadmapper"
        minSdk 26        // API 26 = Android 8.0 (dispatchGesture improvements)
        targetSdk 34
        versionCode 1
        versionName "1.0.0"
    }

    buildTypes {
        release {
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }

    buildFeatures {
        viewBinding true
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = '17'
    }
}

dependencies {
    // ── AndroidX Core ──────────────────────────────────────
    implementation 'androidx.core:core-ktx:1.13.1'
    implementation 'androidx.appcompat:appcompat:1.7.0'
    implementation 'androidx.activity:activity-ktx:1.9.3'
    implementation 'androidx.fragment:fragment-ktx:1.8.5'

    // ── Lifecycle (ViewModel + LiveData) ───────────────────
    implementation 'androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7'
    implementation 'androidx.lifecycle:lifecycle-livedata-ktx:2.8.7'
    implementation 'androidx.lifecycle:lifecycle-runtime-ktx:2.8.7'

    // ── UI ─────────────────────────────────────────────────
    implementation 'com.google.android.material:material:1.12.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.2.0'
    implementation 'androidx.recyclerview:recyclerview:1.3.2'

    // ── Broadcast (LocalBroadcastManager) ─────────────────
    implementation 'androidx.localbroadcastmanager:localbroadcastmanager:1.1.0'

    // ── JSON (Profile persistence) ─────────────────────────
    implementation 'com.google.code.gson:gson:2.11.0'

    // ── Coroutines (async I/O for profile loading) ─────────
    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1'

    // ── USB HID (Android provides natively via InputManager)
    // No extra dependency needed — android.hardware.usb is in the SDK

    // ── Testing ────────────────────────────────────────────
    testImplementation 'junit:junit:4.13.2'
    androidTestImplementation 'androidx.test.ext:junit:1.2.1'
    androidTestImplementation 'androidx.test.espresso:espresso-core:3.6.1'
}
*/
