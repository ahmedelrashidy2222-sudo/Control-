// ═══════════════════════════════════════════════════════════════
// FILE: service/OverlayService.kt
// PURPOSE: Foreground Service that runs during gameplay.
//   - Draws a minimal transparent overlay (catches gamepad events)
//   - Forwards button events → AccessibilityService via broadcasts
//   - Shows a small "GM" pill indicator so user knows it's active
//
// Why needed: Android won't deliver gamepad KeyEvents to a Service
// directly, but they ARE delivered to a View within a Service that
// uses TYPE_ACCESSIBILITY_OVERLAY window.
// ═══════════════════════════════════════════════════════════════
package com.gamepadmapper.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.*
import android.view.*
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.gamepadmapper.R
import com.gamepadmapper.data.GameProfile
import com.gamepadmapper.data.ProfileRepository
import com.gamepadmapper.input.GamepadInput
import com.gamepadmapper.input.GamepadInputManager

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var indicatorView: View? = null

    private lateinit var profileRepository: ProfileRepository
    private var activeProfile: GameProfile? = null

    companion object {
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "gamepad_mapper_channel"

        fun start(context: Context, profileName: String) {
            val intent = Intent(context, OverlayService::class.java).apply {
                putExtra("profile_name", profileName)
            }
            context.startForegroundService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, OverlayService::class.java))
        }
    }

    // ═══════════════════════════════════════════════════════════
    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        profileRepository = ProfileRepository(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification())

        val profileName = intent?.getStringExtra("profile_name") ?: run {
            stopSelf(); return START_NOT_STICKY
        }

        activeProfile = profileRepository.loadProfile(profileName) ?: run {
            stopSelf(); return START_NOT_STICKY
        }

        GamepadInputManager.loadProfile(activeProfile!!)
        GamepadInputManager.isExecutionMode = true
        setupGamepadCallbacks()
        addOverlayView()
        addIndicatorView()

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        GamepadInputManager.isExecutionMode = false
        removeOverlayView()
        removeIndicatorView()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ═══════════════════════════════════════════════════════════
    // Overlay Window
    // ═══════════════════════════════════════════════════════════

    private fun addOverlayView() {
        val params = WindowManager.LayoutParams(
            1, 1,   // 1x1 pixel — just enough to receive key events
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        // This view captures gamepad events via overridden dispatchKeyEvent
        val captureView = object : View(this) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                return GamepadInputManager.handleKeyEvent(event) || super.dispatchKeyEvent(event)
            }
            override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
                return GamepadInputManager.handleMotionEvent(event) || super.dispatchGenericMotionEvent(event)
            }
        }

        overlayView = captureView
        windowManager.addView(captureView, params)
    }

    private fun addIndicatorView() {
        // Small pill in bottom-right corner showing "GM ●" (active indicator)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            bottomMargin = dpToPx(24)
            rightMargin  = dpToPx(24)
        }

        indicatorView = buildIndicatorView()
        windowManager.addView(indicatorView, params)
    }

    private fun buildIndicatorView(): View {
        // Programmatic pill with "GM" text — no XML needed
        val pill = object : View(this) {
            private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#CC0D1117")
            }
            private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#00F5FF")
                textSize = dpToPx(11).toFloat()
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
            }
            private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#4ADE80")  // Green dot = active
            }

            override fun onDraw(canvas: Canvas) {
                val r = dpToPx(16).toFloat()
                canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, paint)
                canvas.drawCircle(width * 0.22f, height / 2f, dpToPx(4).toFloat(), dotPaint)
                canvas.drawText("GM", width * 0.65f, height / 2f + textPaint.textSize / 3, textPaint)
            }
        }

        pill.minimumWidth  = dpToPx(56)
        pill.minimumHeight = dpToPx(28)
        return pill
    }

    private fun removeOverlayView() {
        overlayView?.let { runCatching { windowManager.removeView(it) } }
        overlayView = null
    }

    private fun removeIndicatorView() {
        indicatorView?.let { runCatching { windowManager.removeView(it) } }
        indicatorView = null
    }

    // ═══════════════════════════════════════════════════════════
    // Gamepad → AccessibilityService IPC via LocalBroadcast
    // ═══════════════════════════════════════════════════════════

    private fun setupGamepadCallbacks() {

        // ── Digital Button Press ─────────────────────────────
        GamepadInputManager.onMappedButtonPressed = { mapping ->
            if (!mapping.isAnalog) {
                broadcast(GamepadMapperAccessibilityService.ACTION_TAP_DOWN) {
                    putFloat(GamepadMapperAccessibilityService.EXTRA_X, mapping.screenX)
                    putFloat(GamepadMapperAccessibilityService.EXTRA_Y, mapping.screenY)
                    putString(GamepadMapperAccessibilityService.EXTRA_INPUT_ID, mapping.inputId)
                }
            }
        }

        // ── Digital Button Release ───────────────────────────
        GamepadInputManager.onMappedButtonReleased = { mapping ->
            if (!mapping.isAnalog) {
                broadcast(GamepadMapperAccessibilityService.ACTION_TAP_UP) {
                    putFloat(GamepadMapperAccessibilityService.EXTRA_X, mapping.screenX)
                    putFloat(GamepadMapperAccessibilityService.EXTRA_Y, mapping.screenY)
                    putString(GamepadMapperAccessibilityService.EXTRA_INPUT_ID, mapping.inputId)
                }
            }
        }

        // ── Analog Stick Movement ────────────────────────────
        GamepadInputManager.onMappedAnalogMoved = { mapping, axisX, axisY ->
            broadcast(GamepadMapperAccessibilityService.ACTION_ANALOG_MOVE) {
                putFloat(GamepadMapperAccessibilityService.EXTRA_X, mapping.screenX)
                putFloat(GamepadMapperAccessibilityService.EXTRA_Y, mapping.screenY)
                putFloat(GamepadMapperAccessibilityService.EXTRA_AXIS_X, axisX)
                putFloat(GamepadMapperAccessibilityService.EXTRA_AXIS_Y, axisY)
                putFloat(GamepadMapperAccessibilityService.EXTRA_RADIUS, mapping.analogRadius)
                putString(GamepadMapperAccessibilityService.EXTRA_INPUT_ID, mapping.inputId)
            }
        }
    }

    private fun broadcast(action: String, extras: Intent.() -> Unit) {
        val intent = Intent(action).apply(extras)
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
    }

    // ═══════════════════════════════════════════════════════════
    // Notification
    // ═══════════════════════════════════════════════════════════

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, OverlayService::class.java).apply {
            action = "STOP"
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Gamepad Mapper — Active")
            .setContentText("Controller input is being translated to screen touches.")
            .setSmallIcon(R.drawable.ic_gamepad_notification)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .addAction(R.drawable.ic_stop, "Stop", stopPendingIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Gamepad Mapper",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Shows while gamepad mapping is active" }

            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun dpToPx(dp: Int): Int =
        (dp * resources.displayMetrics.density).toInt()
}
