// ═══════════════════════════════════════════════════════════════
// FILE: MappingActivity.kt
// PURPOSE: Full-screen canvas showing the user's HUD screenshot.
//          Listens for gamepad input → spawns DraggableButtonViews.
//          FAB to save/lock the profile.
// ═══════════════════════════════════════════════════════════════
package com.gamepadmapper

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.gamepadmapper.data.ButtonMapping
import com.gamepadmapper.data.GameProfile
import com.gamepadmapper.input.GamepadInput
import com.gamepadmapper.input.GamepadInputManager
import com.gamepadmapper.ui.DraggableButtonView
import com.gamepadmapper.ui.JoystickOverlayView
import com.gamepadmapper.viewmodel.MappingViewModel
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar

class MappingActivity : AppCompatActivity() {

    // ── ViewModel ─────────────────────────────────────────────
    private val viewModel: MappingViewModel by viewModels()

    // ── Views ─────────────────────────────────────────────────
    private lateinit var rootContainer: FrameLayout
    private lateinit var hudImageView: ImageView
    private lateinit var fabSave: ExtendedFloatingActionButton
    private lateinit var fabUploadHud: FloatingActionButton
    private lateinit var fabHelp: FloatingActionButton

    // ── State ─────────────────────────────────────────────────
    // Maps inputId → its draggable view (to avoid duplicate spawning)
    private val activeButtonViews = mutableMapOf<String, DraggableButtonView>()

    // ── Image picker ─────────────────────────────────────────
    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? -> uri?.let { loadHudImage(it) } }

    // ═══════════════════════════════════════════════════════════
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Immersive dark full-screen
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        )

        setContentView(R.layout.activity_mapping)
        bindViews()
        setupFABs()
        setupGamepadListeners()
        observeViewModel()

        // Load the profile passed via intent
        intent.getStringExtra(EXTRA_PROFILE_NAME)?.let { profileName ->
            viewModel.loadProfile(profileName)
        }
    }

    // ── View Binding ──────────────────────────────────────────
    private fun bindViews() {
        rootContainer = findViewById(R.id.mapping_root_container)
        hudImageView  = findViewById(R.id.hud_image_view)
        fabSave       = findViewById(R.id.fab_save_profile)
        fabUploadHud  = findViewById(R.id.fab_upload_hud)
        fabHelp       = findViewById(R.id.fab_help)
    }

    // ── FAB Setup ─────────────────────────────────────────────
    private fun setupFABs() {
        fabUploadHud.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        fabSave.setOnClickListener {
            lockAndSaveAllMappings()
        }

        fabHelp.setOnClickListener {
            Snackbar.make(
                rootContainer,
                "Press any gamepad button → drag the widget to its location on the HUD → tap 💾 to save",
                Snackbar.LENGTH_LONG
            ).setBackgroundTint(resources.getColor(R.color.surface_elevated, theme))
             .show()
        }
    }

    // ── Gamepad Input Listeners ───────────────────────────────
    private fun setupGamepadListeners() {
        GamepadInputManager.isExecutionMode = false

        // NEW button pressed → spawn widget at center
        GamepadInputManager.onNewButtonDetected = { input ->
            runOnUiThread { spawnButtonWidget(input) }
        }

        // Analog stick moved → spawn/update joystick overlay
        GamepadInputManager.onAnalogAxisDetected = { input, x, y ->
            runOnUiThread { handleAnalogDetected(input, x, y) }
        }
    }

    // ── Spawn Logic ───────────────────────────────────────────

    /**
     * Creates a DraggableButtonView at the center of the canvas.
     * Only called once per unique input (tracked by activeButtonViews).
     */
    private fun spawnButtonWidget(input: GamepadInput) {
        // Don't spawn duplicates
        if (activeButtonViews.containsKey(input.id)) return

        vibrate(30)   // Short haptic feedback on spawn

        val buttonView = DraggableButtonView(
            context      = this,
            gamepadInput = input,
            parentWidth  = rootContainer.width,
            parentHeight = rootContainer.height
        )

        buttonView.onDropped = { finalX, finalY ->
            // Keep track of position in ViewModel for later saving
            viewModel.updateButtonPosition(input.id, finalX, finalY)
        }

        rootContainer.addView(buttonView)
        activeButtonViews[input.id] = buttonView

        showSpawnToast(input.displayName)
    }

    private fun handleAnalogDetected(input: GamepadInput, x: Float, y: Float) {
        // Spawn a JoystickOverlayView if not already present
        if (!activeButtonViews.containsKey(input.id)) {
            val joystickView = JoystickOverlayView(
                context      = this,
                gamepadInput = input,
                parentWidth  = rootContainer.width,
                parentHeight = rootContainer.height
            )
            joystickView.onDropped = { cx, cy ->
                viewModel.updateButtonPosition(input.id, cx, cy)
            }
            rootContainer.addView(joystickView)
            // JoystickOverlayView IS a DraggableButtonView subclass
            activeButtonViews[input.id] = joystickView
        }
    }

    // ── Save / Lock ───────────────────────────────────────────

    private fun lockAndSaveAllMappings() {
        if (activeButtonViews.isEmpty()) {
            Snackbar.make(rootContainer, "No buttons mapped yet!", Snackbar.LENGTH_SHORT).show()
            return
        }

        // Lock all views visually
        activeButtonViews.values.forEach { view ->
            view.playLockAnimation()
        }

        // Build mappings from ViewModel state + analog flags
        val mappings = viewModel.buildMappings(activeButtonViews)

        // Persist to JSON
        viewModel.saveProfile(mappings)

        // Tell GamepadInputManager the new mapped IDs
        mappings.forEach { GamepadInputManager.markAsMapped(it.inputId) }

        fabSave.text = "Profile Saved ✓"
        fabSave.isEnabled = false

        Snackbar.make(
            rootContainer,
            "✅ ${mappings.size} buttons locked. Start your game and enable execution mode!",
            Snackbar.LENGTH_LONG
        ).setAction("How?") {
            // Show the AccessibilityService enable guide
            startActivity(Intent(this, AccessibilityGuideActivity::class.java))
        }.show()

        vibrate(120)
    }

    // ── HUD Image ─────────────────────────────────────────────

    private fun loadHudImage(uri: Uri) {
        try {
            val stream = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(stream)
            hudImageView.setImageBitmap(bitmap)
            hudImageView.scaleType = ImageView.ScaleType.FIT_XY
            viewModel.saveHudImage(uri)
            Toast.makeText(this, "HUD loaded ✓", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not load image: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // ── Gamepad Event Forwarding ──────────────────────────────

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (GamepadInputManager.handleKeyEvent(event)) return true
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (GamepadInputManager.handleMotionEvent(event)) return true
        return super.dispatchGenericMotionEvent(event)
    }

    // ── Utility ───────────────────────────────────────────────

    private fun showSpawnToast(name: String) {
        Snackbar.make(
            rootContainer,
            "📍 \"$name\" detected! Drag it to the right position.",
            Snackbar.LENGTH_SHORT
        ).setBackgroundTint(resources.getColor(R.color.accent_cyan, theme))
         .show()
    }

    @Suppress("DEPRECATION")
    private fun vibrate(ms: Long) {
        val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            v.vibrate(ms)
        }
    }

    private fun observeViewModel() {
        viewModel.hudImageUri.observe(this) { uri ->
            uri?.let { loadHudImage(it) }
        }
    }

    companion object {
        const val EXTRA_PROFILE_NAME = "extra_profile_name"
    }
}
