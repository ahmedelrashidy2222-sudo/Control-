// ═══════════════════════════════════════════════════════════════
// FILE: input/GamepadInputManager.kt
// PURPOSE: Intercepts USB OTG gamepad KeyEvents + MotionEvents,
//          normalizes them, and dispatches to either:
//            (A) MappingActivity  — spawn/detect unmapped buttons
//            (B) AccessibilityService — simulate screen touches
// ═══════════════════════════════════════════════════════════════
package com.gamepadmapper.input

import android.content.Context
import android.content.Intent
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import com.gamepadmapper.data.ButtonMapping
import com.gamepadmapper.data.GameProfile

/**
 * Singleton manager. Attach to an Activity/Service via register().
 * Decouple input routing from UI by using listeners.
 */
object GamepadInputManager {

    // ── Listeners ────────────────────────────────────────────
    /** Called in MAPPING mode: user pressed an unmapped button → spawn UI widget */
    var onNewButtonDetected: ((GamepadInput) -> Unit)? = null

    /** Called in MAPPING mode: user moved an analog stick */
    var onAnalogAxisDetected: ((GamepadInput, Float, Float) -> Unit)? = null

    /** Called in EXECUTION mode: fire a tap/swipe at mapped coords */
    var onMappedButtonPressed: ((ButtonMapping) -> Unit)? = null
    var onMappedButtonReleased: ((ButtonMapping) -> Unit)? = null
    var onMappedAnalogMoved: ((ButtonMapping, Float, Float) -> Unit)? = null

    // ── State ────────────────────────────────────────────────
    private var activeProfile: GameProfile? = null
    var isExecutionMode: Boolean = false   // false = mapping, true = playing

    private val alreadyMappedIds = mutableSetOf<String>()

    // Dead-zone for analog sticks (0.0 – 1.0). Values below this are ignored.
    private const val DEADZONE = 0.15f

    // ── Public API ───────────────────────────────────────────

    fun loadProfile(profile: GameProfile) {
        activeProfile = profile
        alreadyMappedIds.clear()
        alreadyMappedIds.addAll(profile.mappings.map { it.inputId })
    }

    fun clearProfile() {
        activeProfile = null
        alreadyMappedIds.clear()
    }

    fun markAsMapped(inputId: String) {
        alreadyMappedIds.add(inputId)
    }

    // ── Event Handlers (call from Activity overrides) ─────────

    /**
     * Call from Activity.dispatchKeyEvent() or onKeyDown()/onKeyUp().
     * Returns true if the event was consumed.
     */
    fun handleKeyEvent(event: KeyEvent): Boolean {
        if (!isGamepadDevice(event.device)) return false

        val input = GamepadInput.fromKeyCode(event.keyCode)

        return when (event.action) {
            KeyEvent.ACTION_DOWN -> handleButtonDown(input)
            KeyEvent.ACTION_UP   -> handleButtonUp(input)
            else -> false
        }
    }

    /**
     * Call from Activity.dispatchGenericMotionEvent() for analog axes.
     * Returns true if consumed.
     */
    fun handleMotionEvent(event: MotionEvent): Boolean {
        if (!isGamepadDevice(event.device)) return false
        if (event.source and InputDevice.SOURCE_JOYSTICK == 0 &&
            event.source and InputDevice.SOURCE_GAMEPAD == 0) return false

        // ── Left Stick ───────────────────────────────────────
        val lx = applyDeadzone(event.getAxisValue(MotionEvent.AXIS_X))
        val ly = applyDeadzone(event.getAxisValue(MotionEvent.AXIS_Y))
        if (lx != 0f || ly != 0f) {
            routeAnalog(GamepadInput.AxisLeftStick, lx, ly)
        }

        // ── Right Stick ──────────────────────────────────────
        val rx = applyDeadzone(event.getAxisValue(MotionEvent.AXIS_Z))
        val ry = applyDeadzone(event.getAxisValue(MotionEvent.AXIS_RZ))
        if (rx != 0f || ry != 0f) {
            routeAnalog(GamepadInput.AxisRightStick, rx, ry)
        }

        // ── D-Pad Hat Switch (treated as digital inside motion event) ─
        val hatX = event.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hatY = event.getAxisValue(MotionEvent.AXIS_HAT_Y)
        handleHatSwitch(hatX, hatY)

        // ── Analog Triggers ──────────────────────────────────
        val ltVal = event.getAxisValue(MotionEvent.AXIS_LTRIGGER)
            .coerceAtLeast(event.getAxisValue(MotionEvent.AXIS_BRAKE))
        val rtVal = event.getAxisValue(MotionEvent.AXIS_RTRIGGER)
            .coerceAtLeast(event.getAxisValue(MotionEvent.AXIS_GAS))

        if (ltVal > DEADZONE) routeAnalog(GamepadInput.AxisL2Trigger, ltVal, 0f)
        if (rtVal > DEADZONE) routeAnalog(GamepadInput.AxisR2Trigger, rtVal, 0f)

        return true
    }

    // ── Private Routing ─────────────────────────────────────

    private fun handleButtonDown(input: GamepadInput): Boolean {
        if (isExecutionMode) {
            val mapping = findMapping(input.id) ?: return false
            onMappedButtonPressed?.invoke(mapping)
            return true
        } else {
            // MAPPING MODE: only fire if not yet mapped
            if (input.id !in alreadyMappedIds) {
                onNewButtonDetected?.invoke(input)
            }
            return true
        }
    }

    private fun handleButtonUp(input: GamepadInput): Boolean {
        if (isExecutionMode) {
            val mapping = findMapping(input.id) ?: return false
            onMappedButtonReleased?.invoke(mapping)
            return true
        }
        return false
    }

    private fun routeAnalog(input: GamepadInput, x: Float, y: Float) {
        if (isExecutionMode) {
            val mapping = findMapping(input.id) ?: return
            onMappedAnalogMoved?.invoke(mapping, x, y)
        } else {
            // Only fire detection once per axis until user saves
            if (input.id !in alreadyMappedIds) {
                onAnalogAxisDetected?.invoke(input, x, y)
            }
        }
    }

    private fun handleHatSwitch(hatX: Float, hatY: Float) {
        // Map hat switch values to discrete d-pad inputs
        if (hatX > 0.5f)  handleButtonDown(GamepadInput.DpadRight)
        if (hatX < -0.5f) handleButtonDown(GamepadInput.DpadLeft)
        if (hatY > 0.5f)  handleButtonDown(GamepadInput.DpadDown)
        if (hatY < -0.5f) handleButtonDown(GamepadInput.DpadUp)
    }

    private fun findMapping(inputId: String): ButtonMapping? =
        activeProfile?.mappings?.find { it.inputId == inputId }

    private fun applyDeadzone(value: Float): Float =
        if (Math.abs(value) < DEADZONE) 0f else value

    // ── Device Detection ─────────────────────────────────────

    /**
     * Confirms the event source is a physical gamepad/joystick,
     * not a touchscreen or keyboard.
     */
    fun isGamepadDevice(device: InputDevice?): Boolean {
        device ?: return false
        val sources = device.sources
        return (sources and InputDevice.SOURCE_GAMEPAD == InputDevice.SOURCE_GAMEPAD) ||
               (sources and InputDevice.SOURCE_JOYSTICK == InputDevice.SOURCE_JOYSTICK)
    }

    /**
     * Returns a human-readable name for the connected gamepad.
     * Useful for profile naming.
     */
    fun getConnectedGamepadName(context: Context): String? {
        val inputManager = context.getSystemService(Context.INPUT_SERVICE)
                as android.hardware.input.InputManager
        return inputManager.inputDeviceIds
            .mapNotNull { inputManager.getInputDevice(it) }
            .firstOrNull { isGamepadDevice(it) }
            ?.name
    }
}
