// ═══════════════════════════════════════════════════════════════
// FILE: input/GamepadButton.kt
// PURPOSE: All button/axis constants + data models for mappings
// ═══════════════════════════════════════════════════════════════
package com.gamepadmapper.input

import android.view.KeyEvent
import android.view.MotionEvent

/**
 * Unified representation of any gamepad input.
 * Covers digital buttons AND analog axes.
 */
sealed class GamepadInput(val id: String, val displayName: String) {

    // ── Digital Buttons ──────────────────────────────────────
    object ButtonA      : GamepadInput("BTN_A",       "A")
    object ButtonB      : GamepadInput("BTN_B",       "B")
    object ButtonX      : GamepadInput("BTN_X",       "X")
    object ButtonY      : GamepadInput("BTN_Y",       "Y")
    object ButtonL1     : GamepadInput("BTN_L1",      "L1")
    object ButtonR1     : GamepadInput("BTN_R1",      "R1")
    object ButtonL2     : GamepadInput("BTN_L2",      "L2 (Digital)")
    object ButtonR2     : GamepadInput("BTN_R2",      "R2 (Digital)")
    object ButtonL3     : GamepadInput("BTN_L3",      "L3 (Click)")
    object ButtonR3     : GamepadInput("BTN_R3",      "R3 (Click)")
    object ButtonStart  : GamepadInput("BTN_START",   "Start / Options")
    object ButtonSelect : GamepadInput("BTN_SELECT",  "Select / Share")
    object ButtonHome   : GamepadInput("BTN_HOME",    "Home / Guide")
    object DpadUp       : GamepadInput("DPAD_UP",     "D-Pad ↑")
    object DpadDown     : GamepadInput("DPAD_DOWN",   "D-Pad ↓")
    object DpadLeft     : GamepadInput("DPAD_LEFT",   "D-Pad ←")
    object DpadRight    : GamepadInput("DPAD_RIGHT",  "D-Pad →")

    // ── Analog Axes ──────────────────────────────────────────
    object AxisLeftStick  : GamepadInput("AXIS_LEFT",  "Left Stick")
    object AxisRightStick : GamepadInput("AXIS_RIGHT", "Right Stick")
    object AxisL2Trigger  : GamepadInput("AXIS_L2",   "L2 Trigger")
    object AxisR2Trigger  : GamepadInput("AXIS_R2",   "R2 Trigger")

    // ── Unknown (auto-detected) ──────────────────────────────
    data class Unknown(val keyCode: Int)
        : GamepadInput("KEY_$keyCode", "Button #$keyCode")

    companion object {
        fun fromKeyCode(keyCode: Int): GamepadInput = when (keyCode) {
            KeyEvent.KEYCODE_BUTTON_A      -> ButtonA
            KeyEvent.KEYCODE_BUTTON_B      -> ButtonB
            KeyEvent.KEYCODE_BUTTON_X      -> ButtonX
            KeyEvent.KEYCODE_BUTTON_Y      -> ButtonY
            KeyEvent.KEYCODE_BUTTON_L1     -> ButtonL1
            KeyEvent.KEYCODE_BUTTON_R1     -> ButtonR1
            KeyEvent.KEYCODE_BUTTON_L2     -> ButtonL2
            KeyEvent.KEYCODE_BUTTON_R2     -> ButtonR2
            KeyEvent.KEYCODE_BUTTON_THUMBL -> ButtonL3
            KeyEvent.KEYCODE_BUTTON_THUMBR -> ButtonR3
            KeyEvent.KEYCODE_BUTTON_START  -> ButtonStart
            KeyEvent.KEYCODE_BUTTON_SELECT -> ButtonSelect
            KeyEvent.KEYCODE_BUTTON_MODE   -> ButtonHome
            KeyEvent.KEYCODE_DPAD_UP       -> DpadUp
            KeyEvent.KEYCODE_DPAD_DOWN     -> DpadDown
            KeyEvent.KEYCODE_DPAD_LEFT     -> DpadLeft
            KeyEvent.KEYCODE_DPAD_RIGHT    -> DpadRight
            else                           -> Unknown(keyCode)
        }
    }
}

/**
 * A single saved mapping: one GamepadInput → one screen coordinate.
 * For analog sticks, x/y is the CENTER of the joystick touch area,
 * and radius defines how far the simulated finger travels.
 */
data class ButtonMapping(
    val inputId: String,
    val displayName: String,
    val screenX: Float,          // Mapped tap X coordinate (px, absolute)
    val screenY: Float,          // Mapped tap Y coordinate (px, absolute)
    val isAnalog: Boolean = false,
    val analogRadius: Float = 80f  // Max swipe distance for analog axes (dp)
)
