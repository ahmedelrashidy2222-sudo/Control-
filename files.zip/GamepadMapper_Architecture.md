# 🎮 Gamepad Screen Mapper — Android Architecture

## Project Overview
A native Android (Kotlin) app that intercepts USB OTG gamepad input and simulates
screen touches at mapped coordinates using the Android AccessibilityService API.
No root required.

---

## Project Structure

```
GamepadMapper/
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/com/gamepadmapper/
│   │   │   ├── MainActivity.kt                        # App entry, profile picker
│   │   │   ├── MappingActivity.kt                     # HUD canvas + drag/drop
│   │   │   ├── service/
│   │   │   │   ├── GamepadMapperAccessibilityService.kt  # Touch simulation engine
│   │   │   │   └── OverlayService.kt                  # Foreground overlay for execution
│   │   │   ├── input/
│   │   │   │   ├── GamepadInputManager.kt             # USB HID event parsing
│   │   │   │   └── GamepadButton.kt                   # Button/axis constants
│   │   │   ├── ui/
│   │   │   │   ├── DraggableButtonView.kt             # Spawnable, draggable button widget
│   │   │   │   ├── MappingOverlayView.kt              # Full-screen mapping canvas
│   │   │   │   └── JoystickOverlayView.kt             # Analog stick visual + swipe logic
│   │   │   ├── data/
│   │   │   │   ├── ButtonMapping.kt                   # Data model per button
│   │   │   │   ├── GameProfile.kt                     # Collection of mappings
│   │   │   │   └── ProfileRepository.kt              # JSON persistence layer
│   │   │   └── viewmodel/
│   │   │       └── MappingViewModel.kt                # State management (MVVM)
│   │   └── res/
│   │       ├── layout/
│   │       │   ├── activity_main.xml
│   │       │   └── activity_mapping.xml
│   │       ├── xml/
│   │       │   ├── accessibility_service_config.xml   # Required AccessibilityService config
│   │       │   └── device_filter.xml                  # USB device intent filter
│   │       └── values/
│   │           ├── themes.xml                         # Dark gamer theme
│   │           └── colors.xml
│   └── build.gradle
└── build.gradle
```

---

## Architecture Pattern: MVVM + Repository

```
  USB OTG Gamepad
        │
        ▼
  GamepadInputManager          ← Parses HID MotionEvents & KeyEvents
        │
        ▼
  MappingViewModel             ← Holds state: spawned buttons, locked mappings
     │        │
     ▼        ▼
MappingActivity    ProfileRepository  ← Reads/writes profiles.json
     │
     ▼
DraggableButtonView             ← User drags over HUD screenshot
     │
     ▼  (on Lock/Save)
GameProfile (JSON)
     │
     ▼  (on Execute Mode)
OverlayService  ──────────────────►  GamepadMapperAccessibilityService
                  IPC via Broadcast         │
                                            ▼
                                   dispatchGesture()  →  TARGET GAME APP
```

---

## Key Technical Decisions

| Challenge | Solution |
|-----------|----------|
| Touch simulation without root | `AccessibilityService.dispatchGesture()` (API 24+) |
| USB OTG input capture | `InputManager` + `onGenericMotionEvent` / `onKeyDown` |
| Analog stick → swipe translation | Continuous `GestureDescription.StrokeDescription` strokes |
| Overlay on top of games | `TYPE_ACCESSIBILITY_OVERLAY` window via AccessibilityService |
| Mapping persistence | Gson → JSON file in app's private storage |
| Foreground execution | `ForegroundService` with notification |

---

## Required Permissions Summary

```xml
SYSTEM_ALERT_WINDOW           — Draw over other apps (mapping HUD)
FOREGROUND_SERVICE            — Keep overlay alive during gameplay
USB_PERMISSION (custom)       — OTG device access
WRITE_EXTERNAL_STORAGE        — Save HUD screenshot (API < 29)
BIND_ACCESSIBILITY_SERVICE    — Touch injection engine
```
